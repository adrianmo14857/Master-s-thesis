#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2021-09-19 15:01:16

#include "Arduino.h"
#include <RFM69.h>
#include <RFM69_ATC.h>
#include <RFM69_OTA.h>
#include <SPIFlash.h>
#include <SPI.h>
#include <Wire.h>
#include <avr/eeprom.h>
#include <CmdMessenger.h>
#include <utility\\DoEvery.h>
#include <QRM3100.h>
#include <Arduino-MAX17055_Driver.h>
#include <avr/wdt.h>

void attachCommandCallbacks() ;
void OnUnknownCommand() ;
void OnWatchdogRequest() ;
void OnSetLed() ;
void OnSetHighPower() ;
void OnSetACT() ;
void OnSetBoostState() ;
void OnSetLedFrequency() ;
void OnStartLogging() ;
void OnStopLogging() ;
void OnSaveSettings() ;
void OnCalibrate() ;
void OnSetDeviceID() ;
void OnSetNetworkID() ;
void OnSetGatewayID() ;
void OnSetSleepTime() ;
void OnSetSleepTimeMux() ;
void OnSetCycleCount() ;
void OnSetRSSI() ;
void OnSetACK() ;
void OnSetTreshold() ;
void OnSetSecret() ;
void setSecretKey(char *secretPhrasse) ;
void setup() ;
void setupNormal(void) ;
void loop()  ;
void radioInit(void) ;
void blinkLed() ;
uint8_t flashInit(void) ;
uint8_t magInit(void) ;
void checkRM3100(void) ;
void calibrateSensor() ;
unsigned int setupRM3000(void) ;
unsigned int checkCompassState(void) ;
int readVcc(void) ;
void goToSleep(bool enable) ;
void scanI2C() ;
void setWakeUpAlarm(byte sleepSeconds) ;
void rtcInit() ;
void rtcMFP() ;
void Blink(byte PIN, int DELAY_MS) ;
void RtcRamWrite(unsigned char dataAddress, byte data) ;
void RtcRamWritePage(unsigned char dataAddress, byte * page, unsigned char recsize) ;
unsigned char RtcRamRead(unsigned char dataAddress) ;
void RtcRamReadPage(unsigned char dataAddress, byte * p, unsigned char recsize) ;


#include "main.ino"

#endif
