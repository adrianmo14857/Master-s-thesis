#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2021-09-19 15:02:17

#include "Arduino.h"
#include <RFM69.h>
#include <RFM69_ATC.h>
#include <RFM69_OTA.h>
#include <SPIFlash.h>
#include <SPI.h>
#include <Wire.h>
#include <avr/eeprom.h>
#include <CmdMessenger.h>
#include <utility\\DoEvery.h>
#include <avr/wdt.h>

void attachCommandCallbacks() ;
void OnUnknownCommand() ;
void OnWatchdogRequest() ;
void OnSetLed() ;
void OnSetHighPower() ;
void OnSetACT() ;
void OnSetBoostState() ;
void OnSetLedFrequency() ;
void OnStartLogging() ;
void OnStopLogging() ;
void OnSaveSettings() ;
void OnCalibrate() ;
void OnSetDeviceID() ;
void OnSetNetworkID() ;
void OnSetGatewayID() ;
void OnSetSleepTime() ;
void OnSetSleepTimeMux() ;
void OnSetCycleCount() ;
void OnSetRSSI() ;
void OnSetACK() ;
void OnSetTreshold() ;
void OnSetSecret() ;
void setSecretKey(char *secretPhrasse) ;
void OnSetConfig()  ;
void OnGetConfig() ;
void OnGetData() ;
void setup() ;
void setupNormal(void) ;
void loop() ;
uint8_t flashInit(void) ;
void blinkLed(void) ;
void Blink(byte PIN, int DELAY_MS) ;
uint16_t readVcc(void) ;
void radioInit(void) ;


#include "main.ino"

#endif
